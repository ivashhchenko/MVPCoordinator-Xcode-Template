// ___FILEHEADER___

import SwiftUI

extension UIFont {
    var font: Font { .init(self) }
}
