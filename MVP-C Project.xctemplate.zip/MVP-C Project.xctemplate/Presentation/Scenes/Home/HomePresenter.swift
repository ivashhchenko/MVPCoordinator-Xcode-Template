// ___FILEHEADER___

import Foundation

protocol HomePresenterProtocol {
    func onViewDidLoad()
}

final class HomePresenter {
    // MARK: Private Properties
    private weak var viewController: HomeViewControllerProtocol?
    private let coordinator: HomeCoordinatorProtocol
    
    // MARK: Lifecycle
    init(
        viewController: HomeViewControllerProtocol?,
        coordinator: HomeCoordinatorProtocol
    ) {
        self.viewController = viewController
        self.coordinator = coordinator
    }
}

// MARK: - Protocol Implemetation

extension HomePresenter: HomePresenterProtocol {
    func onViewDidLoad() {
        
    }
}
