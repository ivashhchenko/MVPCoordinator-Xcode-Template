// ___FILEHEADER___

import UIKit
import Stevia
import Foundation

protocol HomeViewControllerProtocol: AnyObject {
    
}

final class HomeViewController: UIViewController {
    // MARK: Internal
    var presenter: HomePresenterProtocol?
    
    // MARK: Private
    
    // MARK: Lifecycle
    override func viewDidLoad() {
        super.viewDidLoad()

        setupUI()
        presenter?.onViewDidLoad()
    }
    
    // MARK: Private Methods
    private func setupUI() {
        view.backgroundColor = .purple
        setupLayout()
    }
    
    private func setupLayout() {
        
    }
}

// MARK: - Protocol implementation

extension HomeViewController: HomeViewControllerProtocol {
    
}

