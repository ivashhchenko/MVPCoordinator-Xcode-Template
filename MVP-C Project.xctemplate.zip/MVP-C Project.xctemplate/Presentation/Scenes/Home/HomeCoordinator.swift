// ___FILEHEADER___

import UIKit

protocol HomeCoordinatorProtocol: AnyObject {
    
}

final class HomeCoordinator: Coordinator {
    // MARK: Internal Properties
    let navigationController: UINavigationController
    var children: [Coordinator] = []
    
    // MARK: Lifecycle
    init(navigationController: UINavigationController = .init()) {
        self.navigationController = navigationController
    }

    // MARK: Methods
    func start() {
        let viewController = HomeViewController()
        
        let presenter = HomePresenter(
            viewController: viewController,
            coordinator: self
        )
        viewController.presenter = presenter
        
        navigationController.setViewControllers([viewController], animated: false)
    }
}

extension HomeCoordinator: HomeCoordinatorProtocol {
    
}
