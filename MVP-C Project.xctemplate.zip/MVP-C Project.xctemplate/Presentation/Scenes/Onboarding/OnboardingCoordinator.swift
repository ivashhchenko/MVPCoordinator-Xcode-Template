// ___FILEHEADER___

import UIKit

protocol OnboardingCoordinatorProtocol: AnyObject {
}

final class OnboardingCoordinator: Coordinator {
    // MARK: Internal Properties
    let navigationController: UINavigationController
    var children: [Coordinator] = []
    let onFinish: () -> Void
    
    // MARK: Lifecycle
    init(
        navigationController: UINavigationController = .init(),
        onFinish: @escaping () -> Void
    ) {
        self.navigationController = navigationController
        self.onFinish = onFinish
    }

    // MARK: Methods
    func start() {
        let viewController = OnboardingViewController()
        
        let presenter = OnboardingPresenter(
            viewController: viewController,
            coordinator: self
        )
        viewController.presenter = presenter
        
        navigationController.setViewControllers([viewController], animated: false)
    }
}

extension OnboardingCoordinator: OnboardingCoordinatorProtocol {
    
}
