// ___FILEHEADER___

import UIKit
import Stevia
import Foundation

protocol OnboardingViewControllerProtocol: AnyObject {
    
}

final class OnboardingViewController: UIViewController {
    // MARK: Internal
    var presenter: OnboardingPresenterProtocol?
    
    // MARK: Private
    
    // MARK: Lifecycle
    override func viewDidLoad() {
        super.viewDidLoad()

        setupUI()
        presenter?.onViewDidLoad()
    }
    
    // MARK: Private Methods
    private func setupUI() {
        view.backgroundColor = .purple
        setupLayout()
    }
    
    private func setupLayout() {
        
    }
}

// MARK: - Protocol implementation

extension OnboardingViewController: OnboardingViewControllerProtocol {
    
}

