// ___FILEHEADER___

import Foundation

protocol OnboardingPresenterProtocol {
    func onViewDidLoad()
}

final class OnboardingPresenter {
    // MARK: Private Properties
    private weak var viewController: OnboardingViewControllerProtocol?
    private let coordinator: OnboardingCoordinatorProtocol
    
    // MARK: Lifecycle
    init(
        viewController: OnboardingViewControllerProtocol?,
        coordinator: OnboardingCoordinatorProtocol
    ) {
        self.viewController = viewController
        self.coordinator = coordinator
    }
}

// MARK: - Protocol Implemetation

extension OnboardingPresenter: OnboardingPresenterProtocol {
    func onViewDidLoad() {
        
    }
}
