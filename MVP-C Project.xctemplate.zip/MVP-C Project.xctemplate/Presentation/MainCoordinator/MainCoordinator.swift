// ___FILEHEADER___

import UIKit

class MainCoordinator: Coordinator {
    // MARK: Internal
    var children: [Coordinator] = []
    
    // MARK: Private
    private let window: UIWindow
    
    // MARK: Lifecycle
    init(window: UIWindow) {
        self.window = window
    }
    
    // MARK: Methods
    func start() {
        let homeViewController = makeHomeViewController()
        window.rootViewController = homeViewController
    }
    
    // MARK: Private Methods
    private func makeHomeViewController() -> UIViewController {
        let homeCoordinator = HomeCoordinator()
        homeCoordinator.start()
        children.append(homeCoordinator)
        return homeCoordinator.navigationController
    }
}
