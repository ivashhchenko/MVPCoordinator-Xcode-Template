// ___FILEHEADER___

import UIKit

public protocol Coordinator {
    var children: [Coordinator] { get set }

    func start()
}
