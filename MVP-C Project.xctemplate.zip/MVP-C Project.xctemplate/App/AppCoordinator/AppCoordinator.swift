// ___FILEHEADER___

import UIKit
import Stevia

class AppCoordinator: Coordinator {
    // MARK: Internal
    var children: [Coordinator] = []
    
    // MARK: Private
    private let navigationController = UINavigationController()
    private let window: UIWindow
    
    // MARK: Lifecycle
    init(window: UIWindow) {
        self.window = window
        window.rootViewController = navigationController
        window.makeKeyAndVisible()
    }
    
    // MARK: Methods
    func start() {
        showMain()
    }
    
    // MARK: Private Methods
    private func showOnboarding() {
        let coordinator = OnboardingCoordinator(
            navigationController: navigationController,
            onFinish: { [weak self] in
                self?.children.removeAll { $0 is OnboardingCoordinator }
                self?.showMain()
            }
        )
        coordinator.start()
        children.append(coordinator)
    }
    
    private func showMain() {
        children.removeAll()
        let coordinator = MainCoordinator(window: window)
        coordinator.start()
        children.append(coordinator)
    }
}
